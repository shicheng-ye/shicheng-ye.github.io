# MINIMAL_NODES
here are source examples for minimal nodes, as covered in the text Part 1, Chapter 1.

This package ncludes a minimal publisher, minimal subscriber, minimal simulator and
minimal controller, as well as a launch file.  
